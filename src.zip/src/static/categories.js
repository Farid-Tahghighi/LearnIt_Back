export default [
  "Academics",
  "Development",
  "IT and Network",
  "Business",
  "Music",
  "Finance",
  "Personal Development",
  "Religious",
  "Design",
];
